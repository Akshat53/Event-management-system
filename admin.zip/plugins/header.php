<nav class="navbar navbar-expand-md navbar-dark" style="background-color: black;">
  <div class="container"> 
    <a class="navbar-brand mr-auto" href="index.php"><img src="images/logo1.png" alt="Abhiruchi" style="height: 50px;"></a> 
    <h5 style="color: white;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Abhiruchi Club</h5>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item"> <a class="nav-link" href="index.php">Home</a> </li>
        <li class="nav-item"> <a class="nav-link" href="about.php">About</a> </li>
        <li class="nav-item"> <a class="nav-link" href="gallery.php">Gallery</a> </li>
        <li class="nav-item"> <a class="nav-link" href="contact.php">Contact</a> </li>
        <li class="nav-item"> <a class="nav-link" href="admin/index.php">Login</a> </li>
      </ul>
      <ul class="navbar-nav ml-5">
        <li class="nav-item"> <a class="nav-link" href="https://www.invertisuniversity.ac.in/"><button class="btn btn-danger">Invertis University</button></a> </li>
      </ul>
    </div>
  </div>
</nav>