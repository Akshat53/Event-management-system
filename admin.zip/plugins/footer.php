
<footer class="container-fluid">
  <div class="container">
    <br>
    <br>
    <div class="row">
      <div class="col-md-4 footer1 d-flex wow bounceInLeft" data-wow-delay=".25s">
       
        <hr>
        <br>
        
        <div class="d-flex flex-wrap align-content-center"> <a href="#"><img src="images/logo1.png" alt="logo" style="height: 50px;"/></a>
          <p>ABHIRUCHI (The Hobby Club) provides an appropriate platform to strive the excellence and revealed the true personality of leadership</p>
          <p>&copy; 20201 Abhiruchi. All rights reserved.<br> Design and Developed By <a href="team.php" target="_blank">Project-team</a>.</p>
        </div>
      </div>

      <div class="col-md-4 ">
        <br>
      <br><br><br>
        <div class="container" >
          <div class="row">
            <div class="col "><a href="https://www.facebook.com/CampusLifeAtInvertis/" style="color:white;"><i class="fab fa-facebook fa-3x"></i></a></div>
            <div class="col"><a href="https://api.whatsapp.com/send?phone=919690955599&text=&source=&data=" style="color:white;"><i class="fab fa-whatsapp fa-3x"></i></a></div>
            <div class="col"><a href="https://www.instagram.com/invertis.university/?hl=en" style="color:white;"><i class="fab fa-instagram fa-3x"></i></a></div>

          </div>

        </div>

      </div>
      <div class="col-md-3 footer3 wow bounceInRight" data-wow-delay=".25s">
        <h5>ADDRESS</h5>
        <p>Invertis University is a private university located in Bareilly, Uttar Pradesh, India. It is situated on Bareilly-Lucknow NH-24, </p>
        <h5>PHONE</h5>
        <p>18002745252</p>
        <h5>EMAIL</h5>
        <p>info@invertis.org</p>
        
    </div>
  </div>  
</footer>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/parallax.js"></script>
<script src="js/wow.js"></script>
<script src="js/main.js"></script>
<script src="https://kit.fontawesome.com/cb4a5677fb.js" crossorigin="anonymous"></script>
<!--Carousel part3-->
<script src="js2/popper.js"></script>
<script src="js2/bootstrap.min.js"></script>
<script src="js2/owl.carousel.min.js"></script>
<script src="js2/main.js"></script>
<!--Carousel part3 end   **Take css2 and js2 folder-->