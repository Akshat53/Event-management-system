<?php
include('../dbs/connect.php');
$newid=$_GET['del_id'];

$sql="DELETE from mfactor WHERE id='$newid'";
if (mysqli_query($connect,$sql)) {
    header('location: mfactor.php');
}else{
    echo "Not Deleted";
}
?>
